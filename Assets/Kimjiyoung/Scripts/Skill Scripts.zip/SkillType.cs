using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Skill
{
    public string Name { get;  set; }
    public int SkillLevel { get;  set; }
    public int MaxSkillLevel { get;  set; }
    public bool IsUnLocked { get;  set; }

    public Skill(string name, int maxLevel)
    {
        Name = name;
        MaxSkillLevel = maxLevel;
        SkillLevel = 0;
        IsUnLocked = false;
    }

    public bool Upgrade()
    {
        if (SkillLevel < MaxSkillLevel)
        {
            SkillLevel++;
            if (SkillLevel == MaxSkillLevel)
            {
                IsUnLocked = true;
            }
            return true;
        }
        return false;
    }
}

public class SkillType : MonoBehaviour
{

}
