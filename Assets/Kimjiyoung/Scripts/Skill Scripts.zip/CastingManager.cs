using I18N.Common;
using Photon.Pun.Demo.Cockpit;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngineInternal;



public class CastingManager : MonoBehaviour
{
    public bool skillCasting = false;

    //private CreateFireBall crFireBall;
    private PlayerManagement playerM;
    private ISkillManager manager;



    private void Awake()
    {
        playerM = GetComponent<PlayerManagement>();
        //crFireBall = GetComponent<CreateFireBall>();
        manager = GetComponent<ISkillManager>();
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void fBall1CastingStart()
    {
        //skilldd = true;
        StartCoroutine(FireBall1CastingTime());
    }
    public IEnumerator FireBall1CastingTime()
    {
        playerM.pmAnim.SetBool("IsCasting", true);
        yield return new WaitForSeconds(3f);
        playerM.pmAnim.SetBool("IsCasting", false);
        //skilldd = false;
        Debug.Log(skillCasting);
        //playerM.pmAnim.SetTrigger("IsFireBall");
        manager.FireBalls();
    }


    public void fBall2CastingStart()
    {
        playerM.pmAnim.SetBool("IsCasting", true);
        manager.CreateaBall();
        StartCoroutine(FireBall2CastingTime());
    }

    public IEnumerator FireBall2CastingTime()
    {
        yield return new WaitForSeconds(2.5f);
        playerM.pmAnim.SetBool("IsCasting", false);
        //Debug.Log(skillCasting);
        playerM.pmAnim.SetTrigger("IsFireBall");
        manager.FireBalls();
    }


    public void fBall3CastingStart()
    {
        StartCoroutine(FireBall3CastingTime());
    }

    public IEnumerator FireBall3CastingTime()
    {
        yield return new WaitForSeconds(1.5f);
        Debug.Log(skillCasting);
    }


    public void Icesp1Start()
    {

    }

    public IEnumerator IceSpear1Casting()
    {
        yield return new WaitForSeconds(3f);
    }

    public void Icesp2Start()
    {

    }

    public IEnumerator IceSpear2Casting()
    {
        yield return new WaitForSeconds(2.5f);

    }


    public IEnumerator IceSpear3Casting()
    {
        yield return new WaitForSeconds(1.5f);

    }
}
