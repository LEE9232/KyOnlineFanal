using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ISkillManager : MonoBehaviour
{
    #region GameObject
    public GameObject fireball;
    public GameObject fireBall2;
    //public GameObject fireBall3;
    //public GameObject iceSpear;
    //public GameObject iceaSpear2;
    //public GameObject iceSpear3;
    //public GameObject single;
    //public GameObject wide;
    #endregion
    //public List<GameObject> fireball;

    public Transform pos;
    private IPlayerSkill currentSkill;
    public PlayerManagement playerManagement;
    public fireBallProjectile fireProjec;
    public CastingManager casting { get; set; }

    public float SkillcoolTime;

    private void Awake()
    {
        //ChangeSkill(new StandChar());
        //fireBall = GetComponent<fireBallProjectile>();
        ChangeSkill(new StandChar());
        fireProjec = GetComponent<fireBallProjectile>();
        casting = GetComponent<CastingManager>();
    }

    private void Update()
    {
        if (currentSkill != null)
        {
            currentSkill.UpdateSkill(this);
        }

    }

    public void ChangeSkill(IPlayerSkill newSkill)
    {
        if (currentSkill != null)
        {
            currentSkill.ExitSkill(this);
        }
        currentSkill = newSkill;
        currentSkill.StartSkill(this);
    }
    public void FireBalls()
    {
        print("���̾");
        if (fireProjec.IsFire == false)
        {
            //if (fireball.Count > 0)
            //{
            //    GameObject selectFireBall = fireball[currentSkillIdex];
            //    Instantiate(selectFireBall, pos.position, pos.rotation);
            //    SkillcoolTime = 3f;
            //    StartCoroutine(fireBallProjectile.CoolTime_FireBall1(SkillcoolTime));
            //}

            var obj = Instantiate(fireball, pos.position, pos.rotation);
            StartCoroutine(fireProjec.CoolTime_FireBall1(3f));
        }
    }

    public void CreateaBall()
    {
        //isCasting = true;
        //fireballCast = true;

        var fire2 = Instantiate(fireBall2, pos.position, pos.rotation);

    }


}
