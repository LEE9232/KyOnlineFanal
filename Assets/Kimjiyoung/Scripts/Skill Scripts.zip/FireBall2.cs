using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireBall2 : IPlayerSkill
{
    public void ExitSkill(ISkillManager iSkillManager)
    {

    }

    public void StartSkill(ISkillManager iSkillManager)
    {
        iSkillManager.casting.fBall2CastingStart();
        iSkillManager.ChangeSkill(new StandChar());
    }

    public void UpdateSkill(ISkillManager iSkillManager)
    {

    }

}
