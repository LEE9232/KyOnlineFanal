//using System.Collections;
//using System.Collections.Generic;
//using Unity.Android.Types;
//using UnityEngine;

//public class CreateFireBall : MonoBehaviour
//{
//    public GameObject createFireBallPrefab;
//    public Rigidbody createFireBall;
//    public float castingDuration = 2.4f;
//    private bool isCasting = false;
//    private bool fireballCast = false;

//    private void Awake()
//    {

//    }

//    private void Start()
//    {

//    }

//    private void Update()
//    {

//    }

//    public void CreateaBall()
//    {
//        isCasting = true;
//        fireballCast = true;

//        ISkillManager iskillmanager = GetComponent<ISkillManager>();
//        var fire2 = Instantiate(createFireBallPrefab, iskillmanager.pos.position, iskillmanager.pos.rotation);

//    }
//}
